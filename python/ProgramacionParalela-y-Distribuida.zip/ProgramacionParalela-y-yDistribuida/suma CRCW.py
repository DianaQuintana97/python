import threading
import math
#Diana Quintana Gamboa
#Programacion paralela y distribuida
#Definicion de Funciones
def proceso(i,j):
    b[j]=a[j]+a[j-2**(i-1)]
#Programa principal
a=[]
b=[]
i=1
#a.append(0)

print "-----SUMA Allsums CREW------"
print "Solo se ingresas 8 numeros"

while (i<=8):
    num=int(raw_input("Ingrese dato: "))
    a.append(num)
    i+=1
    
print a
n=len(a)

logy=int(math.log(n,2))

for i in range(0,n):
    b.append(a[i])

    
i=1
while i<=logy:
    j=pow(2,i-1)
    while(j<n):
        t=threading.Thread(target=proceso, args=(i,j,))
        t.start()
        t.join()
        j=j+1
        print j
    i=i+1
    print b
    for k in range(0,n):
        a[k]=(b[k])
 
