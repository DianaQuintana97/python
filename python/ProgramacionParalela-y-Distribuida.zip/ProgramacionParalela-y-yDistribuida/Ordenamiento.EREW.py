from threading import Thread
import os
import math
#DIANA QUINTANA GAMBOA
#PORGRAMACION PARALELA Y DISTRIBUIDA 
#DEFINICION DE FUNCIONES
def hilo3(L2,INI,FIN):
    oddEvenMerge(L2,INI,FIN)
    print "procesos: ",L2[1:FIN+1]
  

def OddEvenMerge(L2,INI,FIN):
    t3=Thread(target=oddEvenMerge,args=(L2,INI,FIN))
    t3.start()
    t3.join()

def oddEvenMerge(L2,INI,FIN):
    m=(FIN-INI)+1
    odd=[0 for _ in range((m/2)+1)]
    even=[0 for _ in range((m/2)+1)]
    if(m==2):
        if(L2[INI]>L2[FIN]):
            intercambio(L2,INI,FIN)
    else:
        oddEvenSplit(L2,odd,even,INI,m)
        t=Thread(target=ordena,args=(odd,(m/2)))
        t.start()
        t.join()
        t2=Thread(target=ordena,args=(even,(m/2)))
        t2.start()
        t2.join()
      
        i=1
        while(i<=(m/2)):
            t=Thread(target=mezcla,args=(L2,odd,even,i,1))
            t.start()
            t.join()
            i=i+1
          
        i=1
        while(i<int(m/2)):
            t=Thread(target=HiloOddEven,args=(L2,i))
            t.start()
            t.join()
            i=i+1
        i=1
        while(i<=int(m/2)):
            t=Thread(target=HiloOddEvenC,args=(L2,i))
            t.start()
            t.join()
            i=i+1
      

def intercambio(L2,INI,FIN):
    aux=L2[INI]
    L2[INI]=L2[FIN]
    L2[FIN]=aux


def oddEvenSplit(L2,odd,even,INI,FIN):
    od=1
    ev=1
    x=INI
    while(x<=FIN):
        if((x%2)==0):
            even[ev]=L2[x]
            ev=ev+1
        else:
            odd[od]=L2[x]
            od=od+1
        x=x+1
    print "ODD >>>: ",odd[1:FIN+1]
    print "\nEVEN >>>: ",even[1:FIN+1]

  
def ordena(L2,FIN):
    L3=L2
    numero=FIN
    OddEvenMerge(L3,1,numero)


def mezcla(L2,odd,even,j,aux):
    m=L2
    impar=odd
    par=even
    m[(2*j)-1]=impar[j]
    m[2*j]=par[j]


def HiloOddEven(num,i):
    numero=num
    j=i
    a=(2*j)
    b=(2*j)+1
    if(numero[a]>numero[b]):
        intercambio(numero,a,b)

def HiloOddEvenC(num,i):
    numero=num
    j=i
    a=(2*j)-1
    b=(2*j)
    if(numero[a]>numero[b]):
        intercambio(numero,a,b)



#Programa Principal
print "========= ORDENAMIENTO EREW ========="
print""
print "\n INGRESE TAMANO DEL VECTOR : "
print"(ATENCION: SOLO PUEDE INGRESAR NUMEROS PARES)"
n=int(raw_input())
while((n%2)!=0):
    print "EL NUMERO NO ES PAR"
    print "INGRESE UN NUMERO PAR: "
    n=int(raw_input())

L=[0 for _ in range(n+1)]
  
i=0
while(i<n):
    x=int(raw_input("\nINGRESE VALOR "))
    L[i+1]=x
    i=i+1
  
print "USTED INGRESO LOS SIGUIENTES VALORES: ",L[1:n+1]
OddEvenMerge(L,1,n)

print "\nEL VECTOR ORDENADO ES: ",L[1:n+1]
