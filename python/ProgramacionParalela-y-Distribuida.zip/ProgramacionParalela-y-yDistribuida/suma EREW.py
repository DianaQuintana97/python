import threading
import math
#DIANA QUINTANA GAMBOA
# "-----SUMA EREW------"
#Definicion de Funciones
def proceso(i,j):
    if((2*j)%(2**i)==0):
        a[(2*j)]=a[(2*j)]+a[((2*j)-(2**(i-1)))]
#Programa principal
a=[]
i=1
a.append(0)
print "-----SUMA EREW------"
print "Solo se ingresas 8 numeros"
while i<=8:
    n=int(raw_input("Ingrese dato: "))
    a.append(n)
    i+=1
n=len(a)
logy=int(math.log(n,2))
print a
i=1
while(i<=logy):
    j=1
    while(j<=n/2):
        t=threading.Thread(target=proceso, args=(i,j,))
        t.start()
        t.join()
        j=j+1
        print j
    print a
    print i
    i=i+1
    
        
    


