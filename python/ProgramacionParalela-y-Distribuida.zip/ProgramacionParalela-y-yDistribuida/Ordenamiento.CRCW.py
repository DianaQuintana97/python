from threading import Thread
import os
import math
#DIANA QUINTANA GAMBOA
#PORGRAMACION PARALELA Y DISTRIBUIDA 
#Definicion de Funciones

def hilo1(win,i):
    win.insert(i,0)


def hilo2(win,i,j):
    if(L[i]>L[j]):
        win[i]=win[i]+1
    else:
        win[j]=win[j]+1


def hilo3(i,win):
    L2.insert(1+win[i],L[i])
    L2.pop(win[i])




#Programa Principal
L=[]
L2=[]
WIN=[]
indexMin=[]

print"==================ORDENAMIENTO CRCW========================"



n=int(raw_input("INGRESE CUATOS VALORES VA A ORDENAR: "))
i=0
while(i<n):
    print "INGRESE VALOR",i+1,":",
    x=int(raw_input())
    L.append(x)
    L2.append(0)
    i=i+1

n=len(L)
print "\nVALORES DE ENTRADA:           ",L
i=1
while(i<=n):
    t=Thread(target=hilo1,args=(WIN,i))
    t.start()
    t.join()
    i=i+1
i=0

while(i<=n):
    j=i+1
    while(j<n and i<j):
        t=Thread(target=hilo2,args=(WIN,i,j))
        t.start()
        t.join()
        j=j+1  
    i=i+1

print "\n WIN:  ",WIN
i=0
while(i<n):
    t=Thread(target=hilo3,args=(i,WIN))
    t.start()
    t.join()
    i=i+1
print "\nVALORES ORDENADOS:             ",L
